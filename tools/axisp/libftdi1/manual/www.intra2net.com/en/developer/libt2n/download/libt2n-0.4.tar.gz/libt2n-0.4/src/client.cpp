/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <sstream>

#include "client.hxx"

namespace libt2n
{

client_connection::client_connection()
    : connection()
{
    set_logging(NULL,none);
}

/// get pointer to logging stream, returns NULL if no logging needed
std::ostream* client_connection::get_logstream(log_level_values level)
{
    if (logstream && log_level >= level)
        return logstream;
    else
        return NULL;
}

/// activate logging to the given stream. everything above the given level is logged.
void client_connection::set_logging(std::ostream *_logstream, log_level_values _log_level)
{
    log_level=_log_level;
    logstream=_logstream;
}

};
