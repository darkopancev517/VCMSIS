/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_SOCKET_CLIENT
#define __LIBT2N_SOCKET_CLIENT

#include "client.hxx"
#include "socket_handler.hxx"

struct sockaddr;

namespace libt2n
{
/** @brief a connection from client to server using sockets.

    Use this class to connect from a client to a server.
 */
class socket_client_connection : public client_connection, public socket_handler
{
    public:
        static const int max_retries_default=3;
        static const long long connect_timeout_usec_default=30000000;

    private:
        void real_write(const std::string& data)
            { socket_write(data); }

        void tcp_connect(int max_retries);
        void unix_connect(int max_retries);
        void connect_with_timeout(struct sockaddr *sock_addr,unsigned int sockaddr_size);

        int max_retries;
        long long connect_timeout_usec;

        std::string path;
        std::string server;
        int port;

        std::string lastErrorMsg;

    protected:

        std::ostream* get_logstream(log_level_values level)
            { return client_connection::get_logstream(level); }

    public:
        socket_client_connection(int _port, const std::string& _server="127.0.0.1", 
            long long _connect_timeout_usec=connect_timeout_usec_default, 
            int _max_retries=max_retries_default,
            std::ostream *_logstream=NULL, log_level_values _log_level=none);
        socket_client_connection(const std::string& _path,
            long long _connect_timeout_usec=connect_timeout_usec_default, 
            int _max_retries=max_retries_default,
            std::ostream *_logstream=NULL, log_level_values _log_level=none);

        /** @brief read data from the socket and copy it into buffer
            @param usec_timeout wait until new data is found, max timeout usecs.
                  -1: wait endless
                   0: return instantly
            @param usec_timeout_remaining if non-NULL the function will write the
                  not used time to the given target
            @retval true if new data was found (does not mean that the received data 
                    is a complete packet though)
        */
        bool fill_buffer(long long usec_timeout=-1, long long *usec_timeout_remaining=NULL)
            { return socket_handler::fill_buffer(buffer,usec_timeout,usec_timeout_remaining); }

        void close();

        void reconnect();

        std::string get_last_error_msg(void)
            { return lastErrorMsg; }
};

}

#endif
