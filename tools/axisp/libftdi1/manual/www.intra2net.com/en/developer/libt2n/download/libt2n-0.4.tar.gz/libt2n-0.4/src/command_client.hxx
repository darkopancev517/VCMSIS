/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_COMMAND_CLIENT
#define __LIBT2N_COMMAND_CLIENT

#include <functional>
#include <string>

#include "client.hxx"
#include "container.hxx"

namespace libt2n
{

/// a client sending out commands to a server
class command_client
{
    public:
        static const long long command_timeout_usec_default=90000000;
        static const long long hello_timeout_usec_default=30000000;

    private:
        client_connection *c;

        long long hello_timeout_usec;
        long long command_timeout_usec;

        void read_hello();
        std::string read_packet(const long long &usec_timeout);
        bool check_hello(const std::string& hellostr);

        std::auto_ptr<t2n_exception> constructorException;

    public:
        command_client(client_connection* _c,
            long long _command_timeout_usec=command_timeout_usec_default,
            long long _hello_timeout_usec=hello_timeout_usec_default);
        virtual ~command_client() {}

        void replace_connection(client_connection* _c);

        void send_command(command* cmd, result_container &res);

        void set_command_timeout_usec(long long _command_timeout_usec=command_timeout_usec_default)
            { command_timeout_usec=_command_timeout_usec; }
        void set_hello_timeout_usec(long long _hello_timeout_usec=hello_timeout_usec_default)
            { hello_timeout_usec=_hello_timeout_usec; }
        long long get_command_timeout_usec(void)
            { return command_timeout_usec; }
        long long get_hello_timeout_usec(void)
            { return hello_timeout_usec; }
        bool is_connection_closed(void)
            { return c->is_closed(); }
        t2n_exception* get_constuctor_exception(void)
            { return constructorException.get(); }
};

}

#endif

