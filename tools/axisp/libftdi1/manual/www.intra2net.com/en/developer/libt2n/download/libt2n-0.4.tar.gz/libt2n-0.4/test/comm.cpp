/***************************************************************************
 *   Copyright (C) 2004 by Intra2net AG                                    *
 *   info@intra2net.com                                                    *
 *                                                                         *
 ***************************************************************************/

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <time.h>

#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>

#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/extensions/HelperMacros.h>

#include <socket_client.hxx>
#include <socket_server.hxx>

using namespace std;
using namespace libt2n;
using namespace CppUnit;


class test_comm : public TestFixture
{
    CPPUNIT_TEST_SUITE(test_comm);

    CPPUNIT_TEST(UnixCommToServer);
    CPPUNIT_TEST(UnixCommToServerAndBack);
    CPPUNIT_TEST(UnixCommToServerAndBackBig);
    CPPUNIT_TEST(IPCommToServer);
    CPPUNIT_TEST(IPCommToServerAndBack);
    CPPUNIT_TEST(IPCommToServerAndBackBig);

    CPPUNIT_TEST_SUITE_END();

    pid_t child_pid;

    public:

    void setUp()
    { }

    void tearDown()
    {
        // make sure the server-child is dead before the next test runs
        kill(child_pid,SIGKILL);
        sleep(1);
    }

    void UnixCommToServer()
    {
        string data;

        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                sc.write("hello");
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                socket_server ss("./socket");

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    if(ss.get_packet(data))
                        break;
                }
            }
        }
        CPPUNIT_ASSERT_EQUAL(string("hello"),data);
    }

    void UnixCommToServerAndBack()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                ss.set_logging(&cerr,debug);

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    string data;
                    unsigned int cid;

                    if(ss.get_packet(data,cid))
                    {
                        server_connection* con=ss.get_connection(cid);

                        if (data=="QUIT")
                            break;

                        if (data=="ABC")
                            con->write("DEF");
                        else
                            con->write("xyz");
                    }
                }
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                string data;

                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");

                sc.write("ABC");

                sc.fill_buffer(1000000);
                sc.get_packet(data);

                CPPUNIT_ASSERT_EQUAL(string("DEF"),data);

                sc.write("HAHA");

                sc.fill_buffer(1000000);
                sc.get_packet(data);

                CPPUNIT_ASSERT_EQUAL(string("xyz"),data);

                sc.write("QUIT");
            }
        }
    }

    void UnixCommToServerAndBackBig()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                ss.set_logging(&cerr,debug);

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    string data;
                    unsigned int cid;

                    if(ss.get_packet(data,cid))
                    {
                        server_connection* con=ss.get_connection(cid);

                        if (data=="QUIT")
                            break;

                        con->write(string().insert(0,100*1024,'y'));
                    }
                }
                std::cerr << "child: OVER" << std::endl;
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                string data;

                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");

                sc.write(string().insert(0,100*1024,'x'));

                while (!sc.get_packet(data))
                    sc.fill_buffer(1000000);

                CPPUNIT_ASSERT_EQUAL(string().insert(0,100*1024,'y'),data);

                sc.write("QUIT");
            }
        }
    }

    void IPCommToServer()
    {
        string data;

        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc(6666);
                sc.write("hello");
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                socket_server ss(6666);

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    if(ss.get_packet(data))
                        break;
                }
            }
        }
        CPPUNIT_ASSERT_EQUAL(string("hello"),data);
    }

    void IPCommToServerAndBack()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss(6666);
                ss.set_logging(&cerr,debug);

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    string data;
                    unsigned int cid;

                    if(ss.get_packet(data,cid))
                    {
                        server_connection* con=ss.get_connection(cid);

                        if (data=="QUIT")
                            break;

                        if (data=="ABC")
                            con->write("DEF");
                        else
                            con->write("xyz");
                    }
                }
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                string data;

                // wait till server is up
                sleep(1);
                socket_client_connection sc(6666);
                sc.write("ABC");

                sc.fill_buffer(1000000);
                sc.get_packet(data);

                CPPUNIT_ASSERT_EQUAL(string("DEF"),data);

                sc.write("HAHA");

                sc.fill_buffer(1000000);
                sc.get_packet(data);

                CPPUNIT_ASSERT_EQUAL(string("xyz"),data);

                sc.write("QUIT");
            }
        }
    }


    void IPCommToServerAndBackBig()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss(6666);
                ss.set_logging(&cerr,debug);

                time_t t0 = time(NULL);

                // max 10 sec
                while (time(NULL) < t0 + 10 )
                {
                    ss.fill_buffer(1000000);

                    string data;
                    unsigned int cid;

                    if(ss.get_packet(data,cid))
                    {
                        server_connection* con=ss.get_connection(cid);

                        socket_handler* alias= dynamic_cast< socket_handler* >(con);

                        if (data=="QUIT")
                            break;

                        alias->set_write_block_size( 4093 );
                        con->write(string().insert(0,2048*1024,'y'));
                    }
                }
                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                string data;

                // wait till server is up
                sleep(1);
                socket_client_connection sc(6666);

                sc.write(string().insert(0,100*1024,'x'));

                while (!sc.get_packet(data))
                    sc.fill_buffer(1000000);

                CPPUNIT_ASSERT_EQUAL(string().insert(0,2048*1024,'y'),data);

                sc.write("QUIT");
            }
        }
    } // eo IPCommToServerAndBackBig()
};

CPPUNIT_TEST_SUITE_REGISTRATION(test_comm);
