/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_CLIENT
#define __LIBT2N_CLIENT

#include <string>
#include <iostream>

#include "connection.hxx"
#include "types.hxx"

namespace libt2n
{

/** @brief a (generic) connection from client to server. Abstract.
 */
class client_connection : public connection
{
    private:
        log_level_values log_level;
        std::ostream *logstream;

    public:
        client_connection();

        void set_logging(std::ostream *_logstream, log_level_values _log_level);

        std::ostream* get_logstream(log_level_values level);
};

}

#endif
