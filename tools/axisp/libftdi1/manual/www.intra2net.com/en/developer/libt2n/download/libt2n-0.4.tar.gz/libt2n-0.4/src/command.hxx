/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_COMMAND
#define __LIBT2N_COMMAND

#include <iostream>

#include <boost/serialization/serialization.hpp>
#include <boost/serialization/tracking.hpp>

namespace libt2n
{

/** @brief base class for the results that are returned from commands.
*/
class result
{
    private:
        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & /* ar */, const unsigned int /* version */)
        { }

    public:
        result() {}
        virtual ~result() {}
};
}
//BOOST_IS_ABSTRACT(libt2n::result)
BOOST_CLASS_TRACKING(libt2n::result, boost::serialization::track_never)

namespace libt2n
{
/** @brief a command that can be serialized. abstract.
*/
class command
{
    private:
        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & /* ar */, const unsigned int /* version */)
        { }

    public:
        /// this calls the wanted target function on the server
        virtual result* operator()()=0;
        virtual ~command() {}
};
} // namespace libt2n
//BOOST_IS_ABSTRACT(libt2n::command)
BOOST_CLASS_TRACKING(libt2n::command, boost::serialization::track_never)


#endif

