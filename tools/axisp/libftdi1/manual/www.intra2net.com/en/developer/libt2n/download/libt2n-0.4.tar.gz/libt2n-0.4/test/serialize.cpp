/***************************************************************************
 *   Copyright (C) 2004 by Intra2net AG                                    *
 *   info@intra2net.com                                                    *
 *                                                                         *
 ***************************************************************************/

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>

#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>

#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/extensions/HelperMacros.h>

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <boost/serialization/serialization.hpp>

#include <container.hxx>
#include <socket_client.hxx>
#include <socket_server.hxx>
#include <command_client.hxx>
#include <command_server.hxx>

using namespace std;
using namespace CppUnit;

string testfunc3(const string& str)
{
    if (str=="throw")
        throw libt2n::t2n_runtime_error("throw me around");
    string ret(str);
    ret+=", testfunc() was here";
    return ret;
}

class testfunc3_res : public libt2n::result
{
    private:
        string res;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::result);
            ar & BOOST_SERIALIZATION_NVP(res);
        }

    public:
        testfunc3_res()
            { }

        testfunc3_res(const string& str)
        {
            res=str;
        }

        string get_data()
        {
            return res;
        }
};


class testfunc3_cmd : public libt2n::command
{
    private:
        string param;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::command);
            ar & BOOST_SERIALIZATION_NVP(param);
        }

    public:
        testfunc3_cmd()
            { }

        testfunc3_cmd(const string& str)
        {
            param=str;
        }

        libt2n::result* operator()()
        {
            return new testfunc3_res(testfunc3(param));
        }
};

#include <boost/serialization/export.hpp>

using namespace libt2n;

class test_serialize : public TestFixture
{
    CPPUNIT_TEST_SUITE(test_serialize);

    CPPUNIT_TEST(ClientSerializeErr);

    // TODO: Server Deserialization Error
    // TODO: Server Serialization Error
    // TODO: Client Deserialization Error
    // but those probably need separate client/server binaries

    CPPUNIT_TEST_SUITE_END();

    pid_t child_pid;

    public:

    void setUp()
    { }

    void tearDown()
    {
        // make sure the server-child is dead before the next test runs
        kill(child_pid,SIGKILL);
        sleep(1);
    }

    void ClientSerializeErr()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                command_server cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                command_client cc(&sc);

                string errormsg;

                result_container rc;
                try
                {
                    cc.send_command(new testfunc3_cmd("xyz"),rc);
                }
                catch(t2n_serialization_error &e)
                    { errormsg=e.what(); }
                catch(...)
                    { throw; }

                CPPUNIT_ASSERT_EQUAL(string("archive_exception while serializing on client-side, code 2 (unregistered class)"),errormsg);
            }
        }
    }

};

CPPUNIT_TEST_SUITE_REGISTRATION(test_serialize);
