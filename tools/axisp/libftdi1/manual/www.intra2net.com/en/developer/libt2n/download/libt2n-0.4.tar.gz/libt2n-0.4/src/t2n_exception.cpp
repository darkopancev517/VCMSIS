/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>

#include "t2n_exception.hxx"

#include <boost/serialization/export.hpp>

BOOST_CLASS_EXPORT(libt2n::t2n_exception)
BOOST_CLASS_EXPORT(libt2n::t2n_communication_error)
BOOST_CLASS_EXPORT(libt2n::t2n_connect_error)
BOOST_CLASS_EXPORT(libt2n::t2n_server_error)
BOOST_CLASS_EXPORT(libt2n::t2n_transfer_error)
BOOST_CLASS_EXPORT(libt2n::t2n_version_mismatch)
BOOST_CLASS_EXPORT(libt2n::t2n_command_error)
BOOST_CLASS_EXPORT(libt2n::t2n_serialization_error)
BOOST_CLASS_EXPORT(libt2n::t2n_runtime_error)

namespace libt2n
{


} // namespace libt2n
