/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_COMMAND_SERVER
#define __LIBT2N_COMMAND_SERVER

#include "command.hxx"
#include "server.hxx"

namespace libt2n
{

/// a server handling incoming commands
class command_server
{
    private:
        server& s;

        void handle_packet(const std::string& packet, server_connection* conn);

        int guard_handle;

    protected:
        virtual command* cast_command(command* input)
            { return input; }

    public:
        command_server(server& _s);

        void handle(long long usec_timeout=-1, long long* usec_timeout_remaining=NULL);

        void send_hello(unsigned int conn_id);

        std::ostream* get_logstream(log_level_values level)
            { return s.get_logstream(level); }
};

template<class T, class B> struct Derived_from {
        static void constraints(T* p) { B* pb = p; }
        Derived_from() { void(*p)(T*) = constraints; }
};

/** @brief server handling group of incoming commands

    the template must be derived from libt2n::command.
*/
template<class COMMAND_GROUP>
class group_command_server : public command_server
{
    private:
        virtual command* cast_command(command* input)
            { return dynamic_cast<COMMAND_GROUP*>(input); }

    public:
        group_command_server(server& _s)
            : command_server(_s)
        { Derived_from<COMMAND_GROUP,command>(); }
};

}
#endif

