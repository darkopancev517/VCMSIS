/***************************************************************************
 *   Copyright (C) 2008 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <functional>
#include <string>

#include <socket_wrapper.hxx>

namespace libt2n
{

/// set logging for coming and current connections
void BasicSocketWrapper::set_logging(std::ostream *_logstream, log_level_values _log_level)
{
    ConnectionWrapper::set_logging(_logstream,_log_level);

    if (connection_established())
        get_connection()->set_logging(_logstream,_log_level);
}


/// return active connection, create new tcp or unix connection if not existing
client_connection* BasicSocketWrapper::get_connection(void)
{
    if (c.get() == NULL)
    {
        if (socket_type == tcp_s)
            c=std::auto_ptr<socket_client_connection>
                (new socket_client_connection(port,server,connect_timeout_usec,max_retries,logstream,log_level));
        else if (socket_type == unix_s)
            c=std::auto_ptr<socket_client_connection>
                (new socket_client_connection(path,connect_timeout_usec,max_retries,logstream,log_level));
    }

    return c.get();
}

/// try to reconnect max_retries time if we encounter a t2n_communication_error 
/// during execution of the command
bool ReconnectSocketWrapper::handle(command_client* stubBase, boost::function< void() > f)
{
    int tries=0;

    while(true)
    {
        try
        {
            // we always reconnect if something went wrong before:
            // makes sure the buffers are clean of half-sent packets etc.
            if (tries > 0)
                c->reconnect();

            f();
            // we were successful
            return true;
        }
        catch(t2n_connect_error &e)
        {
            // reconnect already tries max_tries times to reconnect: we are done if that failed
            throw(e);
        }
        catch(t2n_communication_error &e)
        {
            // aborts the loop with an exception after max_retries iterations
            // retries means that the first try doesn't count: use >
            if (tries > max_retries)
                throw(e);

            // otherwise ignore the exception and reconnect in the next iteration
        }
        catch(...)
        {
            throw;
        }

        tries++;
    }

    return false;
}

/// return active connection, return a dummy-connection if we can't establish one
client_connection* ReconnectIgnoreFailureSocketWrapper::get_connection(void)
{
    client_connection* tmp=BasicSocketWrapper::get_connection();

    if (tmp->is_closed())
    {
        // throw away the closed connection...
        c.reset();
        // ...return the dummy one instead
        tmp=&dc;
    }

    return tmp;
}

/// try to execute the command, may ignore the command if server not available
bool ReconnectIgnoreFailureSocketWrapper::handle(command_client* stubBase, boost::function< void() > f)
{
    if (!connection_established())
    {
        // dummy connection is in place: try to establish a real one
        client_connection* tmp=get_connection();

        if (tmp != &dc)
        {
            // success! we've got a real connection
            stubBase->replace_connection(tmp);
        }
    }

    // only try to handle the call if we've got a real connection
    if (connection_established())
    {
        try
        {
            ReconnectSocketWrapper::handle(stubBase,f);
            return true;
        }
        catch(t2n_communication_error &e)
        {
            // ignore
        }
        catch(...)
        {
            throw;
        }
    }

    return false;
}

}
