/***************************************************************************
 *   Copyright (C) 2004 by Intra2net AG                                    *
 *   info@intra2net.com                                                    *
 *                                                                         *
 ***************************************************************************/

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>

#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>

#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/extensions/HelperMacros.h>

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/export.hpp>

#include <container.hxx>
#include <socket_client.hxx>
#include <socket_server.hxx>
#include <command_client.hxx>
#include <command_server.hxx>

using namespace std;
using namespace CppUnit;
using namespace libt2n;

string testfunc4(const string& str)
{
    if (str=="throw")
        throw libt2n::t2n_runtime_error("throw me around");
    string ret(str);
    ret+=", testfunc() was here";
    return ret;
}

class testfunc4_res : public libt2n::result
{
    private:
        string res;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::result);
            ar & BOOST_SERIALIZATION_NVP(res);
        }

    public:
        testfunc4_res()
            { }

        testfunc4_res(const string& str)
        {
            res=str;
        }

        string get_data()
        {
            return res;
        }
};

class cmd_group_a : public command
{
    private:
        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::command);
        }
};

class cmd_group_b : public command
{
    private:
        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::command);
        }
};

class testfunc4a_cmd : public cmd_group_a
{
    private:
        string param;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(cmd_group_a);
            ar & BOOST_SERIALIZATION_NVP(param);
        }

    public:
        testfunc4a_cmd()
            { }

        testfunc4a_cmd(const string& str)
        {
            param=str;
        }

        libt2n::result* operator()()
        {
            return new testfunc4_res(testfunc4(param));
        }
};

class testfunc4b_cmd : public cmd_group_b
{
    private:
        string param;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(cmd_group_b);
            ar & BOOST_SERIALIZATION_NVP(param);
        }

    public:
        testfunc4b_cmd()
            { }

        testfunc4b_cmd(const string& str)
        {
            param=str;
        }

        libt2n::result* operator()()
        {
            return new testfunc4_res(testfunc4(param));
        }
};


BOOST_CLASS_EXPORT(testfunc4_res)
BOOST_CLASS_EXPORT(cmd_group_a)
BOOST_CLASS_EXPORT(cmd_group_b)
BOOST_CLASS_EXPORT(testfunc4a_cmd)
BOOST_CLASS_EXPORT(testfunc4b_cmd)

class test_cmdgroup : public TestFixture
{
    CPPUNIT_TEST_SUITE(test_cmdgroup);

    CPPUNIT_TEST(GroupOk);
    CPPUNIT_TEST(WrongGroup);

    CPPUNIT_TEST_SUITE_END();

    pid_t child_pid;

    public:

    void setUp()
    { }

    void tearDown()
    {
        // make sure the server-child is dead before the next test runs
        kill(child_pid,SIGKILL);
        sleep(1);
    }

    void GroupOk()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                group_command_server<cmd_group_a> cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc4a_cmd("hello"),rc);

                string ret=dynamic_cast<testfunc4_res*>(rc.get_result())->get_data();

                CPPUNIT_ASSERT_EQUAL(string("hello, testfunc() was here"),ret);
            }
        }
    }

    void WrongGroup()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                group_command_server<cmd_group_b> cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc4a_cmd("hello"),rc);

                string ret;

                try
                {
                    ret=dynamic_cast<testfunc4_res*>(rc.get_result())->get_data();
                }
                catch(t2n_command_error &e)
                    { ret=e.what(); }
                catch(...)
                    { throw; }

                string expected_what="illegal command of type ";

                CPPUNIT_ASSERT_EQUAL(expected_what,ret.substr(0,expected_what.size()));
            }
        }
    }

};

CPPUNIT_TEST_SUITE_REGISTRATION(test_cmdgroup);
