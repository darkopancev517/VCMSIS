/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_LOG
#define __LIBT2N_LOG

#include <iostream>
#include <sstream>

#define LOGGING

#ifdef LOGGING

#define LOGSTREAM(level,pipe) \
            do { \
                std::ostream* streamptr; \
                if ((streamptr=get_logstream(level))!=NULL) \
                    (*streamptr) << pipe << std::endl; \
            } while (0)

#define OBJLOGSTREAM(obj,level,pipe) \
            do { \
                std::ostream* streamptr; \
                if ((streamptr=obj.get_logstream(level))!=NULL) \
                    (*streamptr) << pipe << std::endl; \
            } while (0)

#define EXCEPTIONSTREAM(loglevel,exception,pipe) \
            do { \
                std::ostringstream ostr; \
                ostr << pipe; \
                std::ostream* streamptr; \
                if ((streamptr=get_logstream(loglevel))!=NULL) \
                    (*streamptr) << ostr.str() << std::endl; \
                throw exception(ostr.str()); \
            } while (0)

#else

#define LOGSTREAM(level,pipe)
#define OBJLOGSTREAM(obj,level,pipe)
#define EXCEPTIONSTREAM(loglevel,exception,pipe)

#endif

#endif
