/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

#include <sstream>

#include "socket_server.hxx"
#include "t2n_exception.hxx"
#include "log.hxx"

using namespace std;

namespace libt2n
{

/** @brief create a new tcp-based server
    @param port tcp port you want to listen on
    @param ip the local ip you want to listen on. "0.0.0.0" means all local ips (default).
*/
socket_server::socket_server(int port, const std::string& ip)
    : server(), socket_handler(0,tcp_s)
{
    /* Create the socket. */
    sock = socket (PF_INET, SOCK_STREAM, 0);
    if (sock < 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"error opening socket: " << strerror(errno));

    set_socket_options(sock);

    /* Give the socket a name. */
    struct sockaddr_in sockaddr;
    sockaddr.sin_family = AF_INET;
    sockaddr.sin_port = htons(port);

    if (inet_aton(ip.c_str(),&sockaddr.sin_addr) == 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"failed listening on invalid ip " << ip);

    if (bind (sock, (struct sockaddr *) &sockaddr, sizeof (sockaddr)) < 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"error binding socket: " << strerror(errno));

    start_listening();
}

/** @brief create a new unix-socked-based server
    @param path path of the socket
    @param filemode permissions you want to open the socket with
    @param user local username for the socket
    @param group local groupname for the socket
*/
socket_server::socket_server(const std::string& path, mode_t filemode, const std::string& user, const std::string& group)
    : server(), socket_handler(0,unix_s)
{
    unix_path=path;

    /* Create the socket. */
    sock = socket (PF_UNIX, SOCK_STREAM, 0);
    if (sock < 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"error opening socket: " << strerror(errno));

    set_socket_options(sock);

    /* Give the socket a name. */
    struct sockaddr_un unix_name;
    unix_name.sun_family = AF_UNIX;
    strncpy (unix_name.sun_path, unix_path.c_str(),sizeof(unix_name.sun_path));

    /* just to make sure there is no other socket file */
    unlink (unix_name.sun_path);

    if (bind (sock, (struct sockaddr *) &unix_name, sizeof (unix_name)) < 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"error binding socket: " << strerror(errno));

    /* change permissions */
    if (chmod (unix_name.sun_path, filemode) != 0) 
        EXCEPTIONSTREAM(error,t2n_server_error,"error changing permission: " << strerror(errno));

    if (!user.empty() && !group.empty())
    {
        // TODO maybe use current user/group if one of them is empty

        struct passwd *socket_user = getpwnam (user.c_str());
        if (socket_user == NULL) 
            EXCEPTIONSTREAM(error,t2n_server_error,"error getting socket user: " << strerror(errno));

        struct group *socket_group = getgrnam (group.c_str());
        if (socket_group == NULL) 
            EXCEPTIONSTREAM(error,t2n_server_error,"error getting socket group: " << strerror(errno));

        if (chown (unix_name.sun_path, socket_user->pw_uid, socket_group->gr_gid) != 0) 
            EXCEPTIONSTREAM(error,t2n_server_error,"error changing socket ownership: " << strerror(errno));
    }

    start_listening();
}

socket_server::~socket_server()
{
    socket_handler::close();

    if (get_type()==unix_s)
        unlink(unix_path.c_str());
}

/// start listening on a new server socket (called by the constructors)
void socket_server::start_listening()
{
    if (listen (sock, 5) < 0)
        EXCEPTIONSTREAM(error,t2n_server_error,"error listening to socket: " << strerror(errno));

    /* clear & insert server sock into the fd_tab to prepare select */
    FD_ZERO(&connection_set);
    FD_SET (sock, &connection_set);
}

/// handle a new connection from a client
void socket_server::new_connection()
{
    struct sockaddr_un clientname;

    unsigned int size = sizeof (clientname);
    int newsock = accept (sock,(struct sockaddr *) &clientname,&size);
    if (newsock < 0)
    {
        // return on non-fatal errors (list taken from man-page)
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == ECONNABORTED || errno == EINTR ||
            errno == EMFILE || errno == ENFILE || errno == ENOBUFS || errno == ENOMEM ||
            errno == EPROTO || errno ==  EPERM || errno == ETIMEDOUT)
        {
            LOGSTREAM(error,"non-fatal accept error: " << strerror(errno));
            return;
        }

        /* fatal error: will usually kill or restart the server */
        EXCEPTIONSTREAM(error,t2n_server_error,"fatal error accepting connection: " << strerror(errno));
    }

    FD_SET (newsock, &connection_set);

    socket_server_connection *nc=new socket_server_connection(newsock, get_type(), get_default_timeout());
    nc->set_socket_options(newsock);

    add_connection(nc);

    return;
}

/** @brief look for new connections and new data in any of the existing connections
    @param usec_timeout wait until new data is found, max timeout usecs.
            -1: wait endless
            0: return instantly
    @param usec_timeout_remaining if non-NULL the function will write the
            not used time to the given target
    @retval true if new data was found (does not mean that the received data 
            is a complete packet though)
*/
bool socket_server::fill_buffer(long long usec_timeout,long long* usec_timeout_remaining)
{
    fd_set used_fdset=connection_set;

    /* set timeout */
    struct timeval tval;
    struct timeval *timeout_ptr;

    if (usec_timeout == -1)
        timeout_ptr = NULL;
    else
    {
        timeout_ptr = &tval;

        // timeout von long long usec in int sec + int usec umrechnen
        tval.tv_sec = usec_timeout / 1000000;
        tval.tv_usec = usec_timeout % 1000000;
    }

    int ret=select (FD_SETSIZE, &used_fdset, NULL, NULL, timeout_ptr);

    // return the timeout we did not use
    if (usec_timeout > 0 && usec_timeout_remaining != NULL)
        *usec_timeout_remaining=(tval.tv_sec*1000000)+tval.tv_usec;

    if (ret < 0)
    {
        if (errno == EINTR)
        {
            // select interrupted by signal
            ret=0;
        }
        else
            EXCEPTIONSTREAM(error,t2n_server_error,"select error: " << strerror(errno));
    }

    if (ret > 0)
    {
        // we have data pending

        // check for new connection
        if (FD_ISSET (sock, &used_fdset))
        {
            new_connection();
        }

        // check all connections for pending data
        return fill_connection_buffers();
    }

    return false;
}

/// call fill_buffer() on all connections, called from fill_buffer()
bool socket_server::fill_connection_buffers()
{
    bool data_found;

    std::map<unsigned int, server_connection*>::iterator ie=connections.end();
    for(std::map<unsigned int, server_connection*>::iterator i=connections.begin(); i != ie; i++)
        if (!i->second->server_connection::is_closed())
        {
            // shutdown all connections which throw exceptions to protect the server
            try
            {
                if (i->second->fill_buffer(0))
                    data_found=true;
            }
            catch (t2n_transfer_error &e)
                { i->second->close(); }
            catch(...)
                { throw; }
        }

    return data_found;
}

/// remove the socket of a connection after the connection has been closed
void socket_server::remove_connection_socket(int sock)
{
    FD_CLR(sock, &connection_set);
}

/// close this connection. complete data waiting in the buffer can still be retrieved.
void socket_server_connection::close()
{
    if (!server_connection::is_closed())
    {
        socket_handler::close();
        server_connection::close();
    }

    if (my_server)
    {
        dynamic_cast<socket_server*>(my_server)->remove_connection_socket(sock);
    }
}

}
