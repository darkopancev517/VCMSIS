/***************************************************************************
 *   Copyright (C) 2008 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <client_wrapper.hxx>

namespace libt2n
{

const char* T2nSingletonWrapperMessages::NotInitializedMessage = "T2nSingletonWrapper used before setting initializing connection";

/// get pointer to logging stream, returns NULL if no logging needed
std::ostream* ConnectionWrapper::get_logstream(log_level_values level)
{
    if (logstream && log_level >= level)
        return logstream;
    else
        return NULL;
}

/// activate logging to the given stream. everything above the given level is logged.
void ConnectionWrapper::set_logging(std::ostream *_logstream, log_level_values _log_level)
{
    log_level=_log_level;
    logstream=_logstream;
}

/// always call this when you got a new connection to transfer logging settings
void ConnectionWrapper::set_logging_on_connection(client_connection& c)
{
    if (logstream != NULL && log_level > none)
        c.set_logging(logstream,log_level);
}

}
