/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>

#include "container.hxx"

#include <boost/serialization/export.hpp>

BOOST_CLASS_EXPORT(libt2n::result_container)
BOOST_CLASS_EXPORT(libt2n::command_container)

namespace libt2n
{


/// deletes the carried result or exception objects
result_container::~result_container()
{
    if (res)
        delete res;
    if (ex)
        delete ex;
}

/** @brief returns the result or throw the carried exception.
            ATTENTION: the result object is deleted in the destructor
*/
result* result_container::get_result(void)
{
    if (result_type==exception)
        ex->do_throw();
    return res;
}

/// deletes the carried command
command_container::~command_container()
{
    if (cmd)
        delete cmd;
}

} // namespace libt2n
