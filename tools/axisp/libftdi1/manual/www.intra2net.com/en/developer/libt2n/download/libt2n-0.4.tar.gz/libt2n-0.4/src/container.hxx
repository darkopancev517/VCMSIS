/***************************************************************************
 *   Copyright (C) 2006 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __LIBT2N_CONTAINER
#define __LIBT2N_CONTAINER

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <boost/serialization/serialization.hpp>

#include "command.hxx"
#include "t2n_exception.hxx"

#include <iostream>

namespace libt2n
{

/** @brief contains the result (return value as libt2n::result or an libt2n::t2n_exception) of a executed command
*/
class result_container
{
    private:
        enum result_type_t { regular, exception } result_type;

        result *res;
        t2n_exception *ex;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version);

    public:
        result_container()
            { res=0; ex=0; }

        result_container(result *_res)
            { set_result(_res); }
        result_container(t2n_exception *_ex)
            { set_exception(_ex); }

        ~result_container();

        void set_result(result *_res)
            { res=_res; ex=0; result_type=regular; }
        void set_exception(t2n_exception *_ex)
            { res=0; ex=_ex; result_type=exception; }

        result* get_result(void);

        bool has_exception()
            { return (result_type==exception); }
        bool has_result()
            { return (result_type==regular); }
};

/** @brief contains a libt2n::command
*/
class command_container
{
    private:
        command *cmd;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version);

    public:
        command_container()
            { cmd=0; }
        command_container(command *_cmd)
            { cmd=_cmd; }

        ~command_container();

        /// return the contained command
        command* get_command()
            { return cmd; }
};

} // namespace libt2n

BOOST_CLASS_TRACKING(libt2n::result_container, boost::serialization::track_never)
BOOST_CLASS_TRACKING(libt2n::command_container, boost::serialization::track_never)

#include "container.tcc"

#endif

