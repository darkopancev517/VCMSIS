/***************************************************************************
 *   Copyright (C) 2004 by Intra2net AG                                    *
 *   info@intra2net.com                                                    *
 *                                                                         *
 ***************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>

#include <time.h>
#include <sys/timeb.h>

#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/TestListener.h>
#include <cppunit/TestFailure.h> 
#include <cppunit/TestResult.h> 
#include <cppunit/CompilerOutputter.h> 

class VerboseTimingListener : public CppUnit::TestListener
{
    private:
        double start_time;
        std::string resultstr;

        double get_time(void)
        {
            struct timeb tb;
            ftime(&tb);
            return tb.time+(static_cast<float>(tb.millitm)/1000);
        }
    
    public:
   
        void startTest( CppUnit::Test *test )
        {
            resultstr="OK";
            std::cout << test->getName() << ": ";
            start_time=get_time();
        }
    
        void endTest( CppUnit::Test *test )
        {
            double timediff=get_time()-start_time;
            
            // fix clock unpreciseness for small timespans
            if (timediff < 0) timediff=0;
            
            std::cout << resultstr << " (" 
                      << std::fixed << std::setprecision(3) 
                      << timediff << " sec)" << std::endl;
        }

        void addFailure(const CppUnit::TestFailure &failure)
        {
            if(failure.isError())
                resultstr="ERROR";
            else
                resultstr="FAIL";
        }
};

int main(int argc, char **argv)
{
    CppUnit::TextTestRunner runner;
    CppUnit::TestFactoryRegistry &registry = CppUnit::TestFactoryRegistry::getRegistry();
    
    // set output format that KDevelop can catch errors
    CppUnit::CompilerOutputter *op=CppUnit::CompilerOutputter::defaultOutputter(&runner.result(),std::cout);
    op->setLocationFormat("%p:%l: error: ");
    runner.setOutputter(op);

    // show every test with timing
    VerboseTimingListener listener;        
    runner.eventManager().addListener(&listener); 
    
    runner.addTest(registry.makeTest());
    
    // run all tests in registry (not using the default progress listener)
    bool wasSucessful = runner.run("",false,true,false);
    
    return (wasSucessful ? 0 : 1);
}
