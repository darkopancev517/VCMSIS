/***************************************************************************
 *   Copyright (C) 2008 by Gerd v. Egidy                                   *
 *   gve@intra2net.com                                                     *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef __LIBT2N_SOCKET_WRAPPER
#define __LIBT2N_SOCKET_WRAPPER

#include <functional>
#include <string>

#include <client.hxx>
#include <command_client.hxx>
#include <types.hxx>
#include <client_wrapper.hxx>
#include <socket_client.hxx>

namespace libt2n
{

/** @brief a basic implementation of ConnectionWrapper

    This is a basic version of a ConnectionWrapper which does not do any fancy
    error handling or anything, it justs executes the regular calls. Use this
    wrapper if you only want to use the singleton-feature of T2nSingletonWrapper.
*/
class BasicSocketWrapper : public ConnectionWrapper
{
    protected:
        socket_type_value socket_type;

        std::string path;
        std::string server;
        int port;

        long long connect_timeout_usec;
        int max_retries;

        std::auto_ptr<socket_client_connection> c;

    public:
        BasicSocketWrapper(int _port, const std::string& _server="127.0.0.1", 
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : port(_port), server(_server), connect_timeout_usec(_connect_timeout_usec),
              max_retries(_max_retries), socket_type(tcp_s), ConnectionWrapper()
            { }

        BasicSocketWrapper(const std::string& _path,
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : path(_path), connect_timeout_usec(_connect_timeout_usec),
              max_retries(_max_retries), socket_type(unix_s), ConnectionWrapper()
            { }

        client_connection* get_connection(void);

        bool connection_established(void)
            { return (c.get() != NULL); }

        void set_logging(std::ostream *_logstream, log_level_values _log_level);
};

/** @brief a wrapper implementing reconnect-then-throw

    This ConnectionWrapper tries to reconnect to the server if something with the connection
    goes wrong. If even reconnecting max_retries times does not help, an exception is thrown.
*/
class ReconnectSocketWrapper : public BasicSocketWrapper
{
    public:
        ReconnectSocketWrapper(int _port, const std::string& _server="127.0.0.1", 
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : BasicSocketWrapper(_port,_server,_connect_timeout_usec,_max_retries)
            { }

        ReconnectSocketWrapper(const std::string& _path,
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : BasicSocketWrapper(_path,_connect_timeout_usec,_max_retries)
            { }

        bool handle(command_client* stubBase, boost::function< void() > f);
};

/// a placeholder-client_connection which is closed all the time
class dummy_client_connection : public client_connection
{
    private:
        void real_write(const std::string& data)
            { }

    public:
        dummy_client_connection()
            : client_connection()
            { close(); }

        bool fill_buffer(long long usec_timeout=-1, long long *usec_timeout_remaining=NULL)
            { return false; }
};

/** @brief a wrapper implementing reconnect-then-ignore

    This ConnectionWrapper tries to reconnect to the server if something with the connection
    goes wrong. If even reconnecting max_retries times does not help, the complete t2n-call is
    ignored. The return value of the call will be created with the default constructor.
*/
class ReconnectIgnoreFailureSocketWrapper : public ReconnectSocketWrapper
{
    private:
        dummy_client_connection dc;

    public:
        ReconnectIgnoreFailureSocketWrapper(int _port, const std::string& _server="127.0.0.1", 
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : ReconnectSocketWrapper(_port,_server,_connect_timeout_usec,_max_retries)
            { }

        ReconnectIgnoreFailureSocketWrapper(const std::string& _path,
            long long _connect_timeout_usec=socket_client_connection::connect_timeout_usec_default, 
            int _max_retries=socket_client_connection::max_retries_default)
            : ReconnectSocketWrapper(_path,_connect_timeout_usec,_max_retries)
            { }

        client_connection* get_connection(void);
        bool handle(command_client* stubBase, boost::function< void() > f);
};

}

#endif
