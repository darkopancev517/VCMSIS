/***************************************************************************
 *   Copyright (C) 2004 by Intra2net AG                                    *
 *   info@intra2net.com                                                    *
 *                                                                         *
 ***************************************************************************/

#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>

#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>

#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/extensions/HelperMacros.h>

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <boost/serialization/serialization.hpp>

#include <container.hxx>
#include <socket_client.hxx>
#include <socket_server.hxx>
#include <command_client.hxx>
#include <command_server.hxx>

using namespace std;
using namespace CppUnit;

string testfunc(const string& str)
{
    string ret;
    if (str=="throw")
        throw libt2n::t2n_runtime_error("throw me around");
    if (str=="big")
        ret.insert(0,100*1024,'x');
    else
        ret=str+", testfunc() was here";
    return ret;
}

class testfunc_res : public libt2n::result
{
    private:
        string res;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::result);
            ar & BOOST_SERIALIZATION_NVP(res);
        }

    public:
        testfunc_res()
            { }

        testfunc_res(const string& str)
        {
            res=str;
        }

        string get_data()
        {
            return res;
        }
};


class testfunc_cmd : public libt2n::command
{
    private:
        string param;

        friend class boost::serialization::access;
        template<class Archive>
        void serialize(Archive & ar, const unsigned int version)
        {
            ar & BOOST_SERIALIZATION_BASE_OBJECT_NVP(libt2n::command);
            ar & BOOST_SERIALIZATION_NVP(param);
        }

    public:
        testfunc_cmd()
            { }

        testfunc_cmd(const string& str)
        {
            param=str;
        }

        libt2n::result* operator()()
        {
            return new testfunc_res(testfunc(param));
        }
};

#include <boost/serialization/export.hpp>

BOOST_CLASS_EXPORT(testfunc_cmd)
BOOST_CLASS_EXPORT(testfunc_res)

using namespace libt2n;

class test_simplecmd : public TestFixture
{
    CPPUNIT_TEST_SUITE(test_simplecmd);

    CPPUNIT_TEST(SimpleCmd);
    CPPUNIT_TEST(SimpleException);
    CPPUNIT_TEST(BigReturn);
    CPPUNIT_TEST(BigParameter);

    CPPUNIT_TEST_SUITE_END();

    pid_t child_pid;

    public:

    void setUp()
    { }

    void tearDown()
    {
        // make sure the server-child is dead before the next test runs
        kill(child_pid,SIGKILL);
        sleep(1);
    }

    void SimpleCmd()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                command_server cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                sc.set_logging(&cerr,debug);
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc_cmd("hello"),rc);

                string ret=dynamic_cast<testfunc_res*>(rc.get_result())->get_data();

                CPPUNIT_ASSERT_EQUAL(string("hello, testfunc() was here"),ret);
            }
        }
    }

    void SimpleException()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                command_server cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                sc.set_logging(&cerr,debug);
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc_cmd("throw"),rc);

                string ret;

                try
                {
                    ret=dynamic_cast<testfunc_res*>(rc.get_result())->get_data();
                }
                catch(t2n_runtime_error &e)
                    { ret=e.what(); }
                catch(...)
                    { throw; }

                CPPUNIT_ASSERT_EQUAL(string("throw me around"),ret);
            }
        }
    }

    void BigReturn()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                command_server cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc_cmd("big"),rc);

                string ret=dynamic_cast<testfunc_res*>(rc.get_result())->get_data();

                CPPUNIT_ASSERT_EQUAL(string().insert(0,100*1024,'x'),ret);
            }
        }
    }

    void BigParameter()
    {
        switch(child_pid=fork())
        {
            case -1:
            {
                CPPUNIT_FAIL("fork error");
                break;
            }
            case 0:
            // child
            {
                socket_server ss("./socket");
                command_server cs(ss);

                // max 10 sec
                for (int i=0; i < 10; i++)
                    cs.handle(1000000);

                // don't call atexit and stuff
                _exit(0);
            }

            default:
            // parent
            {
                // wait till server is up
                sleep(1);
                socket_client_connection sc("./socket");
                command_client cc(&sc);

                result_container rc;
                cc.send_command(new testfunc_cmd(string().insert(0,100*1024,'y')),rc);

                string ret=dynamic_cast<testfunc_res*>(rc.get_result())->get_data();

                CPPUNIT_ASSERT_EQUAL(string().insert(0,100*1024,'y')+", testfunc() was here",ret);
            }
        }
    }

};

CPPUNIT_TEST_SUITE_REGISTRATION(test_simplecmd);
